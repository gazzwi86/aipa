import boto3
import os
from datetime import datetime, timedelta

ecs = boto3.client('ecs', region_name=os.environ.get('AWS_REGION_NAME', 'ap-southeast-2'))
cloudwatch = boto3.client('cloudwatch', region_name=os.environ.get('AWS_REGION_NAME', 'ap-southeast-2'))

CLUSTER = os.environ['ECS_CLUSTER']
SERVICE = os.environ['ECS_SERVICE']
IDLE_TIMEOUT = int(os.environ.get('IDLE_TIMEOUT_MIN', '30'))
API_GATEWAY_ID = os.environ['API_GATEWAY_ID']

def handler(event, context):
    """
    Check if the service has been idle and shut it down if so.
    Uses API Gateway request count as the activity metric.
    """
    try:
        # First check if service is running
        response = ecs.describe_services(cluster=CLUSTER, services=[SERVICE])
        if not response['services']:
            return {'status': 'service_not_found'}

        service = response['services'][0]
        if service['desiredCount'] == 0:
            return {'status': 'already_stopped'}

        if service['runningCount'] == 0:
            return {'status': 'starting_up'}

        # Check API Gateway metrics for recent activity
        end_time = datetime.utcnow()
        start_time = end_time - timedelta(minutes=IDLE_TIMEOUT)

        response = cloudwatch.get_metric_statistics(
            Namespace='AWS/ApiGateway',
            MetricName='Count',
            Dimensions=[
                {'Name': 'ApiId', 'Value': API_GATEWAY_ID}
            ],
            StartTime=start_time,
            EndTime=end_time,
            Period=IDLE_TIMEOUT * 60,  # Entire window as one period
            Statistics=['Sum']
        )

        # Get total request count in the idle window
        total_requests = 0
        for datapoint in response.get('Datapoints', []):
            total_requests += datapoint.get('Sum', 0)

        # Exclude wake/status/shutdown calls (they shouldn't count as activity)
        # We'll be conservative and require at least 5 real requests
        if total_requests < 5:
            print(f"Service idle for {IDLE_TIMEOUT} minutes ({total_requests} requests). Shutting down.")
            ecs.update_service(
                cluster=CLUSTER,
                service=SERVICE,
                desiredCount=0
            )
            return {
                'status': 'shutdown',
                'reason': f'Idle for {IDLE_TIMEOUT} minutes',
                'requests': total_requests
            }

        return {
            'status': 'active',
            'requests': total_requests
        }

    except Exception as e:
        print(f"Error checking idle status: {e}")
        return {'status': 'error', 'message': str(e)}
