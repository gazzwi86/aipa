import boto3
import json
import os
import time

ecs = boto3.client('ecs', region_name=os.environ.get('AWS_REGION_NAME', 'ap-southeast-2'))

CLUSTER = os.environ['ECS_CLUSTER']
SERVICE = os.environ['ECS_SERVICE']

def handler(event, context):
    """
    Handle wake-up, status check, and shutdown requests.

    Actions:
    - wake: Start the ECS service if not running
    - status: Check if the service is running and healthy
    - shutdown: Scale the service to 0
    """
    # Parse action from path or body
    action = 'status'

    if event.get('rawPath'):
        path = event['rawPath']
        if '/wake' in path:
            action = 'wake'
        elif '/shutdown' in path:
            action = 'shutdown'
        elif '/status' in path:
            action = 'status'
    elif event.get('action'):
        action = event['action']

    try:
        # Get current service state
        response = ecs.describe_services(cluster=CLUSTER, services=[SERVICE])

        if not response['services']:
            return error_response(404, 'Service not found')

        service = response['services'][0]
        desired_count = service['desiredCount']
        running_count = service['runningCount']

        if action == 'wake':
            return handle_wake(desired_count, running_count)
        elif action == 'shutdown':
            return handle_shutdown(desired_count)
        else:  # status
            return handle_status(desired_count, running_count)

    except Exception as e:
        return error_response(500, str(e))

def handle_wake(desired_count, running_count):
    """Start the service if not running."""
    if desired_count == 0:
        # Scale up
        ecs.update_service(
            cluster=CLUSTER,
            service=SERVICE,
            desiredCount=1
        )
        return success_response({
            'status': 'starting',
            'message': 'Service is starting. Please wait 30-60 seconds.',
            'desiredCount': 1,
            'runningCount': 0
        })
    elif running_count == 0:
        return success_response({
            'status': 'starting',
            'message': 'Service is starting. Please wait.',
            'desiredCount': desired_count,
            'runningCount': 0
        })
    else:
        return success_response({
            'status': 'running',
            'message': 'Service is already running.',
            'desiredCount': desired_count,
            'runningCount': running_count
        })

def handle_shutdown(desired_count):
    """Scale the service to 0."""
    if desired_count > 0:
        ecs.update_service(
            cluster=CLUSTER,
            service=SERVICE,
            desiredCount=0
        )
        return success_response({
            'status': 'stopping',
            'message': 'Service is shutting down.'
        })
    else:
        return success_response({
            'status': 'stopped',
            'message': 'Service is already stopped.'
        })

def handle_status(desired_count, running_count):
    """Return current service status."""
    if desired_count == 0:
        status = 'stopped'
    elif running_count == 0:
        status = 'starting'
    else:
        status = 'running'

    return success_response({
        'status': status,
        'desiredCount': desired_count,
        'runningCount': running_count
    })

def success_response(body):
    return {
        'statusCode': 200,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps(body)
    }

def error_response(code, message):
    return {
        'statusCode': code,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps({'error': message})
    }
